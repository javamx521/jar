var e=Object.defineProperty||!1;if(e)try{e({},"a",{value:1})}catch(r){e=!1}var a=e;export{a as e};
