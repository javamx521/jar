import{s as r}from"./request-5e162f1f.js";import{q as s}from"./qs-7741cc00.js";function t(t){return r({url:`/rcs/api/v1/workstation/page?${s.stringify(t)}`,method:"GET"})}export{t as A};
