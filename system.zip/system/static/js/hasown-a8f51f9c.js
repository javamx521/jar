import{r}from"./function-bind-61718806.js";var t,o;function n(){if(o)return t;o=1;var n=Function.prototype.call,a=Object.prototype.hasOwnProperty,c=r();return t=c.call(n,a)}export{n as r};
