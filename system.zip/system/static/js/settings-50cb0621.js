import{s as r}from"./request-bcbcbd50.js";import{q as s}from"./qs-12f5342e.js";function t(t){return r({url:`/rcs/api/v1/workstation/page?${s.stringify(t)}`,method:"GET"})}export{t as A};
