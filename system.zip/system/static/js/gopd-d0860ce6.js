var r=Object.getOwnPropertyDescriptor;if(r)try{r([],"length")}catch(e){r=null}var t=r;export{t as g};
