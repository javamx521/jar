var r=TypeError,a=Error,e=EvalError,o=RangeError,s=ReferenceError,E=SyntaxError,n=URIError;export{e as _,s as a,a as e,o as r,E as s,r as t,n as u};
