import{f as r}from"./function-bind-d3395e5a.js";var t,o;function n(){if(o)return t;o=1;var n=Function.prototype.call,a=Object.prototype.hasOwnProperty;return t=r.call(n,a)}export{n as r};
